def test1
end

def test2(page, pages_count, path)
  pages_links = 5
  page_idx = page - 1


  paginate = Paginate.new()

  pg_item = Pg_item.new()
  if pages_count > pages_links*2
    pg_item.label = '<<'
    pg_item.visible = true
    if page_idx < pages_links
      pg_item.active = false
    else
      pg_item.link = sh_path
      pg_item.active = true
    end
  else
    pg_item.visible = false
  end
  paginate.first = pg_item

  pg_item = Pg_item.new()
  if pages_count > pages_links
    pg_item.label = '<'
    pg_item.link = path
    pg_item.visible = true
    if page_idx < pages_links
      pg_item.active = false
    else
      pg_item.active = true
    end
  else
    pg_item.visible = false
  end
  paginate.prev = pg_item

  paginate.current = []
  if pages_count >= pages_links
    start_page_idx = page_idx - (page_idx % pages_links)
    begin_idx = start_page_idx + 1
    end_idx = start_page_idx + pages_links
  else
    begin_idx = 1
    end_idx = pages_count
  end
  for i in begin_idx .. end_idx
    pg_item = Pg_item.new()

    pg_item.label = i.to_s
    pg_item.link = sh_path(page: i.to_s)
    pg_item.is_current = (i == page)

    paginate.current << pg_item
  end

  pg_item = Pg_item.new()
  if pages_count > pages_links
    pg_item.label = '>'
    pg_item.link = path
    pg_item.visible = true
    if page_idx < pages_links
      pg_item.active = false
    else
      pg_item.active = true
    end
  else
    pg_item.visible = false
  end
  paginate.next = pg_item

  pg_item = Pg_item.new()
  if pages_count > pages_links*2
    pg_item.label = '>>'
    pg_item.link = path
    pg_item.visible = true
    if page_idx < pages_links
      pg_item.active = false
    else
      pg_item.active = true
    end
  else
    pg_item.visible = false
  end
  paginate.last = pg_item

  paginate
end

def sh_path(page_param = nil)
  if page_param.nil? || page_param[:page].nil?
    '/shop?page='
  elsif page_param[:page].to_s == 1
    '/shop?page='
  else
    '/shop?page=' + page_param[:page].to_s
  end
  # page_param.inspect
end

def paginate(page, pages_count)
  pages_links = 5
  page_idx = page - 1
  # p page_idx.to_s
  start_page_idx = page_idx - (page_idx % pages_links)
  # p start_page_idx.to_s
  start_page = start_page_idx + 1
  # p start_page.to_s
  end_page = start_page_idx + pages_links
  if end_page < page
    end_page = page
  end
  # p end_page.to_s

  paginator = []

  if page > pages_links*2
    paginator << '<<'
  else
    paginator << '<< (-)'
  end

  if page > pages_links
    paginator << '<'
  else
    paginator << '< (-)'
  end

  if pages_count >= pages_links
    begin_idx = start_page
    end_idx = end_page
    if end_idx > pages_count
      end_idx = pages_count
    end
  else
    begin_idx = 1
    end_idx = pages_count
  end

  for i in begin_idx .. end_idx
    if i == page
      paginator << 'curr ' + (i).to_s
    else
      paginator << (i).to_s
    end
  end

  if end_page < pages_count
    paginator << '>'
  else
    paginator << '> (-)'
  end

  if end_page < pages_count - pages_links
    paginator << '>>'
  else
    paginator << '>> (-)'
  end

  paginator
end

Paginate = Struct.new(:first, :prev, :current, :next, :last)
Pg_item = Struct.new(:label, :link, :active, :visible, :is_current)


def test_pafinate
# p paginate(5,60)

# p sh_path({page: 10})

  p '1..3'
  p '.. ..'
  p paginate(1, 3)

  p '1..5'
  p '.. ..'
  p paginate(1, 5)

  p '6..7'
  p '.< ..'
  p paginate(6, 7)

  p '7..12'
  p '.< ..'
  p paginate(7, 12)

  p '10..12'
  p '.< ..'
  p paginate(10, 12)

  p '11..12'
  p '<< < ..'
  p paginate(11, 12)
  p '40..42'
  p '<< < ..'
  p paginate(40, 42)

  p '1..3'
  p '.. ..'
  p paginate(1, 3)

  p '1..5'
  p '.. ..'
  p paginate(1, 5)

  p '1..6'
  p '.. >.'
  p paginate(1, 6)

  p '3..6'
  p '.. >.'
  p paginate(3, 6)

  p '1..11'
  p '.. > >>'
  p paginate(1, 11)

  p '40..50'
  p '.. > >>'
  p paginate(40, 50)

  p '49..51'
  p '.. >.'
  p paginate(49, 51)
end

a = 0
if a
  puts 'a'
else
  puts 'b'
end