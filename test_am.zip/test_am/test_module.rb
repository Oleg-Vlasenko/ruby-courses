module TestModule
  def test_m
    p 'test'
  end

  class Cls
    def class_method
      p 'clss meth'
    end
  end
end